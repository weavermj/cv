BBC Pagination - Interview Task for Matthew Weaver
--------------------------------------------------

I have chosen to implement the pagination device in JavaScript as a jQuery plugin. 

In this zip file there is another zip file called BBCPaginate.zip. To see a basic example of my plugin at work, extract these files to a folder and open demo.html in a browser. Everything needed to use the plugin on any website is included in this zip.

The Website folder contains a mini-site that I have set up to showcase the full functionality of my plugin, including multiple demos with live data, a full read me guide explaining how the plugin can be customised at run-time plus information on my testing methodology. 

For best results, you can view the website and full documentation online at http://www.weavermj.co.uk/bbc/. If you prefer to run it locally, launch index.html (please note that Chrome does not allow loading of static JSON data with relative file paths, so for viewing examples of my device using the static data please view in Firefox or Safari - this only applies to the local copy, not the hosted version on the web).

I look forward to meeting you at the interview on Thursday.

Best regards,

Matt

 
